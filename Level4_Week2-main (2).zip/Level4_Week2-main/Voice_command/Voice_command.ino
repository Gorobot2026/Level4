
// LCD Library 
#include <Wire.h>
#include <LiquidCrystal_I2C.h>
LiquidCrystal_I2C lcd(0x27, 16, 2); // Address >> 0x27 (GREEN) หรือ 0x3F (BLUE) 

//voice recognition 
#include <SoftwareSerial.h>
#include "VoiceRecognitionV3.h"
VR myVR(2,3);    // 2:RX 3:TX, you can choose your favourite pins.
uint8_t records[7]; // save record
uint8_t buf[64];

//*********************************edit**********************************
#define command0 (0)         //Name command 0
#define command1 (1)         //Name command 1
#define command2 (2)         //Name command 2
#define command3 (3)         //Name command 3
#define command4 (4)         //Name command 4
#define command5 (5)         //Name command 5
#define command6 (6)         //Name command 6
//***********************************************************************

void setup() {
  // put your setup code here, to run once:
  myVR.begin(9600);
  Serial.begin(9600);

  lcd.init();
  lcd.backlight();
  setup_command();
 //***************************************voice************************
  if(myVR.clear() == 0){
    Serial.println("Recognizer cleared.");
  }else{
    Serial.println("Not find VoiceRecognitionModule.");
    Serial.println("Please check connection and restart Arduino.");
    while(1);
  }  
   if(myVR.load((uint8_t)command0) >= 0){       //edit Name command 0 Name to match the line 32
   }
  if(myVR.load((uint8_t)command1) >= 0){       //edit Name command 1 Name to match the line 33
  }
  if(myVR.load((uint8_t)command2) >= 0){    //edit Name command 2 Name to match the line 34
  }
  if(myVR.load((uint8_t)command3) >= 0){    //edit Name command 3 Name to match the line 35
  }
  if(myVR.load((uint8_t)command4) >= 0){    //edit Name command 4 Name to match the line 36
  }
  if(myVR.load((uint8_t)command5) >= 0){    //edit Name command 5 Name to match the line 37
  }
  if(myVR.load((uint8_t)command6) >= 0){    //edit Name command 6 Name to match the line 38
  }
  //*********************************************************************

}
void loop() {
   speech_command();
}

