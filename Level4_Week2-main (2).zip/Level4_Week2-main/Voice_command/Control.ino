void setup_command() {
  lcd_print(1, "ROBOT HEAD", 1, "Have A good day ");  //print ข้อความ ลง LCD Lcd_print(ตำแหน่งแถว 0 , ข้อความ แถว0 , ตำแหน่งแถว 1 , ข้อความ แถว 1)
}

void speech_command() {
  int state;
  state = myVR.recognize(buf, 50);
  if (state > 0) {
    switch (buf[1]) {

        //*************************************************************************************************************
      case Hello:  //command 0
        lcd_print(1, "Hello...", 1, " How are you?");
        break;

      case command1:  //Robot
        lcd_print(1, "IDEKTEP ", 1, "LEVEL 4 Welcome..");  //print ข้อความ ลง LCD Lcd_print(ตำแหน่งแถว 0 , ข้อความ แถว0 , ตำแหน่งแถว 1 , ข้อความ แถว 1)
        break;

      case command2:
        lcd_print(2, "COLOR CODE:", 4, "RED");  //print ข้อความ ลง LCD Lcd_print(ตำแหน่งแถว 0 , ข้อความ แถว0 , ตำแหน่งแถว 1 , ข้อความ แถว 1)
        break;

      case command3:
        lcd_print(2, "COLOR CODE:", 4, "GREEN");  //print ข้อความ ลง LCD Lcd_print(ตำแหน่งแถว 0 , ข้อความ แถว0 , ตำแหน่งแถว 1 , ข้อความ แถว 1)
        break;

      case command4:
        lcd_print(1, "sleeping.....", 0, "z..z..z..z..");  //print ข้อความ ลง LCD Lcd_print(ตำแหน่งแถว 0 , ข้อความ แถว0 , ตำแหน่งแถว 1 , ข้อความ แถว 1)
        break;

      case command5:
        lcd_print(1, "See you", 1, "Again... kids");
        break;

      case command6:

        break;

      default:
        lcd.clear();
        lcd.setCursor(2, 0);
        lcd.print("Record function undefined");
        break;
    }
    printVR(buf);
  }
}